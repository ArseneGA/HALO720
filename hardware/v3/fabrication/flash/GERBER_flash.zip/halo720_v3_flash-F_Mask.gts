%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*%
%TF.CreationDate,2026-11-25T12:13:03+01:00*%
%TF.ProjectId,halo720_v3_flash,68616c6f-3732-4305-9f76-335f666c6173,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-11-25 12:13:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.200000*%
%ADD11R,2.800000X0.550000*%
%ADD12R,2.800000X1.000000*%
%ADD13RoundRect,0.250000X1.500000X-0.250000X1.500000X0.250000X-1.500000X0.250000X-1.500000X-0.250000X0*%
%ADD14RoundRect,0.250001X1.449999X-0.499999X1.449999X0.499999X-1.449999X0.499999X-1.449999X-0.499999X0*%
G04 APERTURE END LIST*
D10*
X2600000Y2600000D03*
D11*
X8000000Y5325000D03*
D12*
X8000000Y4200000D03*
D11*
X8000000Y3075000D03*
X8000000Y10925000D03*
D12*
X8000000Y9800000D03*
D11*
X8000000Y8675000D03*
D13*
X16150000Y6000000D03*
X16150000Y8000000D03*
D14*
X21900000Y3650000D03*
X21900000Y10350000D03*
D10*
X2600000Y11400000D03*
M02*
